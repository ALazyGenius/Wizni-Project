import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "search",
  pure: false
})
export class FilterPipe implements PipeTransform {
    transform(items: any[], term): any {
        console.log('term', term);
        console.log('items', items);
        return term ? items.filter(item => item.referenceId.indexOf(term) !== -1 || item.fromContact.indexOf(term) !== -1 || item.toContact.indexOf(term) !== -1 || item.countryCode.indexOf(term) !== -1 || item.cityCode.indexOf(term) !== -1 || item.fullAddress.indexOf(term) !== -1 || item.phoneNumber.indexOf(term) !== -1 || item.status.indexOf(term) !== -1) : items;
    }
}