import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataParserApiService } from '../services/data-parser-api.service';

@Component({
  selector: 'list-data',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})

export class ListComponent implements OnInit {
  consignmentList: any;
  key: string = 'refId'; //set default
  reverse: boolean = false;

  constructor(private router: Router, private consignmentService: DataParserApiService) { }

  ngOnInit() {
    this.consignmentService.getConsignmentDetails()
      .subscribe(response => {
        this.consignmentList = response.json();
      })
  }

  _addConsignment(e) {
    console.log("Add consignment");
    this.router.navigate(["/add-consignment"]);
  }

  _printContents(e) {
    console.log("Print contents");
  }

  _edit(item) {
    console.log(item)
    this.consignmentService.dataForSelectedRow(item);
    this.router.navigate(["/edit-consignment"]);
  }

  _delete(id) {
    console.log("Id to be deleted", id);
    var deleteRow = confirm("Are you sure you want to delete!");
    if (deleteRow == true) {
      this.consignmentService.deleteConsignmentDetails(id)
      .subscribe(response => {
        for (var i = 0; i < this.consignmentList.length; i++) {
          if(this.consignmentList[i].id === id) {
            this.consignmentList.splice(i,1);
            console.log("Consignment list", this.consignmentList);
          }
        }
      })
    }
  }

  sort(key){
    this.key = key;
    this.reverse = !this.reverse;
  }
}
