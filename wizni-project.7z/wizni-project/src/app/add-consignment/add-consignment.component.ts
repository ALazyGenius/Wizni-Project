import { DataParserApiService } from './../services/data-parser-api.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms'

@Component({
  selector: 'add-consignment',
  templateUrl: './add-consignment.component.html',
  styleUrls: ['./add-consignment.component.css']
})
export class AddConsignmentComponent implements OnInit {
  statusArray: any[] = [];
  addConsignment: Boolean = false;
  lastId: number;

  form = new FormGroup({
    consignmentFrom: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    consignmentTo: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    country: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(10),
    ]),
    city: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(10),
    ]),
    address: new FormControl('', [
      Validators.required,
      Validators.minLength(15),
      Validators.maxLength(50),
    ]),
    phoneNumber: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(10),
    ]),
    status: new FormControl('', [])
  })

  constructor(private router: Router, private consignmentService: DataParserApiService) {
    this.statusArray = ['Delayed', 'Delivered', 'Returned', 'Shipped']
  }

  ngOnInit() {
  }

  _add(e) {
    this.addConsignment = true;
  }

  _addConsignment(e) {
    this.addConsignment = true;
    var objToPost = {};
    objToPost['fromContact'] = this.form.value.consignmentFrom;
    objToPost['toContact'] = this.form.value.consignmentTo;
    objToPost['countryCode'] = this.form.value.country;
    objToPost['cityCode'] = this.form.value.city;
    objToPost['fullAddress'] = this.form.value.address;
    objToPost['phoneNumber'] = this.form.value.phoneNumber.toString();
    objToPost['referenceId'] = this.generate(6);
    objToPost['status'] = (<HTMLInputElement>document.getElementById('status')).value;
    this.consignmentService.getConsignmentDetails()
      .subscribe(response => {
        var resp = response.json();
        this.lastId = resp[resp.length - 1].id;
        console.log(this.lastId);
        this.consignmentService.postNewConsignmentDetails(this.lastId, objToPost)
          .subscribe(response => {
            console.log("Response", response.json());
          });
          this.router.navigate([""]);
      })
  }

  generate(n) {
    var add = 1, max = 12 - add;
    if (n > max) {
      return this.generate(max) + this.generate(n - max);
    }
    max = Math.pow(10, n + add);
    var min = max / 10;
    var number = Math.floor(Math.random() * (max - min + 1)) + min;
    return ("" + number).substring(add);
  }

  _back() {
    this.router.navigate([""]);
  }

  get consignmentFrom() {
    return this.form.get('consignmentFrom');
  }

  get consignmentTo() {
    return this.form.get('consignmentTo');
  }

  get country() {
    return this.form.get('country');
  }

  get city() {
    return this.form.get('city');
  }

  get address() {
    return this.form.get('address');
  }

  get phoneNumber() {
    return this.form.get('phoneNumber');
  }

  get status() {
    return this.form.get('status');
  }


}
