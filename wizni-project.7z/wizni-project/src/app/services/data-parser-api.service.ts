import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class DataParserApiService {
  consignmentList: any;
  dataForSelectedRowArray: any[] = [];
  consignmentSetFlag: Boolean = false;
  constructor(private http: Http) { }

  getConsignmentDetails() {
    return this.http.get('http://localhost:3000/consignments');
  }

  postNewConsignmentDetails(id, consignmentObject) {
    console.log(consignmentObject);
    consignmentObject['id'] = id+1;
    console.log(consignmentObject);
    return this.http.post('http://localhost:3000/consignments', consignmentObject);
  }
  
  putNewConsignmentDetails(id, consignmentObject) {
    console.log(consignmentObject);
    return this.http.put('http://localhost:3000/consignments' + '/' + id, consignmentObject);
  }

  deleteConsignmentDetails(id) {
    return this.http.delete('http://localhost:3000/consignments' + '/' + id);
  }

  dataForSelectedRow(data) {
    this.dataForSelectedRowArray = data;
  }

  getDataForSelectedRow() {
    return this.dataForSelectedRowArray
  }
}
