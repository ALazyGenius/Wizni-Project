import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { DataParserApiService } from './../services/data-parser-api.service';
import { concat } from 'rxjs/internal/observable/concat';

@Component({
  selector: 'edit-consignment',
  templateUrl: './edit-consignment.component.html',
  styleUrls: ['./edit-consignment.component.css']
})

export class EditConsignmentComponent implements OnInit {
  statusArray: any[] = [];
  selectedRowData: any;
  id: Number;
  referenceId: String;
  addConsignment: Boolean = false;
  lastId: number;

  form = new FormGroup({
    consignmentFrom: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    consignmentTo: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(20),
    ]),
    country: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(10),
    ]),
    city: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(10),
    ]),
    address: new FormControl('', [
      Validators.required,
      Validators.minLength(15),
      Validators.maxLength(50),
    ]),
    phoneNumber: new FormControl('', [
      Validators.required,
      Validators.minLength(6),
      Validators.maxLength(10),
    ])
  })

  constructor(private router: Router, private consignmentService: DataParserApiService) {
    this.statusArray = ['Delayed', 'Delivered', 'Returned', 'Shipped']
  }

  ngOnInit() {
    this.selectedRowData = this.consignmentService.getDataForSelectedRow();
    console.log(this.selectedRowData)
    this.id = this.selectedRowData.id;
    this.referenceId = this.selectedRowData.referenceId;
  }

  _edit(e) {
    this.addConsignment = true;
  }

  _editConsignment(e) {
    this.addConsignment = true;
    var objToPost = {};
    console.log(this.form.value);
    objToPost['fromContact'] = (<HTMLInputElement>document.getElementById('consignmentFrom')).value;
    objToPost['toContact'] = (<HTMLInputElement>document.getElementById('consignmentTo')).value;
    objToPost['countryCode'] = (<HTMLInputElement>document.getElementById('country')).value;
    objToPost['cityCode'] = (<HTMLInputElement>document.getElementById('city')).value;
    objToPost['fullAddress'] = (<HTMLInputElement>document.getElementById('address')).value;
    objToPost['phoneNumber'] = (<HTMLInputElement>document.getElementById('phoneNumber')).value;
    objToPost['status'] = (<HTMLInputElement>document.getElementById('status')).value;
    objToPost['referenceId'] = this.referenceId;
    console.log(objToPost);
    this.consignmentService.putNewConsignmentDetails(this.id, objToPost)
      .subscribe(response => {
        console.log("Response", response.json())
      });
    this.router.navigate([""]);
  }

  _back() {
    this.router.navigate([""]);
  }

  get consignmentFrom() {
    return this.form.get('consignmentFrom');
  }

  get consignmentTo() {
    return this.form.get('consignmentTo');
  }

  get country() {
    return this.form.get('country');
  }

  get city() {
    return this.form.get('city');
  }

  get address() {
    return this.form.get('address');
  }

  get phoneNumber() {
    return this.form.get('phoneNumber');
  }


}

