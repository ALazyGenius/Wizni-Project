import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'wizni-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  pulldataFlag: boolean = true;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  _pullData(e) {
    console.log("Inside pull data");
    this.pulldataFlag = false;
    this.router.navigate(["/data", !this.pulldataFlag]);
  }

  myFunction() {
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
  }
}