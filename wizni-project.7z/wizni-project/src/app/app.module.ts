import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { Ng2OrderModule } from 'ng2-order-pipe';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ListComponent } from './list/list.component';
import { EditConsignmentComponent } from './edit-consignment/edit-consignment.component';
import { AddConsignmentComponent } from './add-consignment/add-consignment.component';

import { DataParserApiService } from './services/data-parser-api.service';

import { FilterPipe } from './pipes/pipes';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ListComponent,
    EditConsignmentComponent,
    AddConsignmentComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2OrderModule,
    RouterModule.forRoot([
      {
        path: '',
        component: HomeComponent
      },
      {
        path: 'data/:flag',
        component: ListComponent
      },
      {
        path: 'add-consignment',
        component: AddConsignmentComponent
      },
      {
        path: 'edit-consignment',
        component: EditConsignmentComponent
      }
    ]),
  ],
  providers: [
    DataParserApiService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
